[![Review Assignment Due Date](https://classroom.github.com/assets/deadline-readme-button-22041afd0340ce965d47ae6ef1cefeee28c7c493a6346c4f15d667ab976d596c.svg)](https://classroom.github.com/a/Jwdk2u8p)
# cosc2804-assignment3-template

Team members:
1. Khanh Nguyen (s4090097@student.rmit.edu.au)
Github username: Khanh Nguyen (s4090097)
Task assigned: Maze Generation + E3 Enhancements

2. Jason Xu (s4094183@student.rmit.edu.au)
Github username: Jason12322
Task assigned: Maze Solving + E1 Enhancements

3. Brian Chau (s4100533@student.rmit.edu.au)
Github username: BrianChau0
Task assigned: Build maze & Cleaning the world


Link to video - https://rmiteduau.sharepoint.com/:v:/s/Team8-Studio2/EShBBf2DAolGkmRZiyfuuaoBz07-dpu8kumAvUCkpBaZMA


Have to be logged in RMIT account